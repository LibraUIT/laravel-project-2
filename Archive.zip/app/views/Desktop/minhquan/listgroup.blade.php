@extends("Desktop.master")
@section('content')
<div class="listgroup">
	<h1>Group {{$group->name}}</h1>
</div>
@stop
