'use strict'

configControllers.controller('ProfileController', ['$scope', '$rootScope', '$route','$routeParams', '$location','$http', '$state', 'CategoryService',
  function($scope, $rootScope, $route ,$routeParams, $location, $http, $state, CategoryService) {
    document.title = 'AdminLTE | Profile';
    
}]);